<template>
  <v-row>
    <v-col sm="12" cols="12" class="pt-0" style=" height: 200px;text-align: center;">
        <h1 class="mt-6">Comming Soon...</h1>
    </v-col>
  </v-row>
</template>

<script>
</script>
<style scoped>
</style>
