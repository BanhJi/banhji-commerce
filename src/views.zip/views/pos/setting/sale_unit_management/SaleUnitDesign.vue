<template>
  <v-row>
    <v-col sm="12" cols="12" class="grayBg px-6">
        <v-card color="white" class="pa-3 no_border" elevation="0">
          <v-row>
              <v-col sm="12" cols="12" class="pt-0" style=" height: 200px;text-align: center;">
                  <h1 class="mt-6">Comming Soon...</h1>
              </v-col>
          </v-row>
        </v-card>
    </v-col>
  </v-row>
</template>

<script>
</script>
<style scoped>
</style>
